package Modele;

public class Activitee implements java.io.Serializable{
	private int idAct;
	private String libelAct;
	
	public int getIdAct() {
		return idAct;
	}

	public void setIdAct(int idAct) {
		this.idAct = idAct;
	}

	public String getLibelAct() {
		return libelAct;
	}

	public void setLibelAct(String libelAct) {
		this.libelAct = libelAct;
	}

	public int getNbPratAct() {
		return nbPratAct;
	}

	public void setNbPratAct(int nbPratAct) {
		this.nbPratAct = nbPratAct;
	}

	private int nbPratAct;
	
	public Activitee(int _idAct, String _libelAct){
		idAct = _idAct;
		libelAct = _libelAct;
	}
}
