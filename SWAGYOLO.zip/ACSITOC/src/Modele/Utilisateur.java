package Modele;

public class Utilisateur implements java.io.Serializable {

	private int idUtilisateur;
	private String nomUtilisateur;
	private String mdpUtilisateur;
	private int status; //1=Admin, 2=entraineur, 3=utilisateur lambada ^^
	
	private String idEvenement;
	private String idActivite;
	
	public int getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(int _idUtilisateur) {
		this.idUtilisateur = _idUtilisateur;
	}

	public String getNomUtilisateur() {
		return nomUtilisateur;
	}

	public void setNomUtilisateur(String _nomUtilisateur) {
		this.nomUtilisateur = _nomUtilisateur;
	}

	public String getIdEvenement() {
		return idEvenement;
	}

	public void setIdEvenement(String _idEvenement) {
		this.idEvenement = _idEvenement;
	}

	public String getIdActivite() {
		return idActivite;
	}

	public void setIdActivite(String _idActivite) {
		this.idActivite = _idActivite;
	}

	//Constructeur	
	
	public Utilisateur( int _idUtilisateur, String _nomPersonne, String _mdpUtilisateur, int _status){
		idUtilisateur = _idUtilisateur;
		nomUtilisateur = _nomPersonne;
		mdpUtilisateur = _mdpUtilisateur;
		status =_status;
	}
}
