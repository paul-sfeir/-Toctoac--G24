package vue;

import java.awt.EventQueue;



import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Scrollbar;

import javax.swing.JSeparator;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;

import com.toedter.calendar.JCalendar;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollBar;

public class Vue_TocToac_Lambda {

    private JCalendar c;
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vue_TocToac_Lambda window = new Vue_TocToac_Lambda();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Vue_TocToac_Lambda() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
       
       
		frame = new JFrame();
		frame.setBounds(100, 100, 635, 376);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel(" ");
		lblNewLabel_1.setBounds(122, 9, 3, 14);
		panel_1.add(lblNewLabel_1);
	       
	       JLayeredPane layeredPane = new JLayeredPane();
	       layeredPane.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	       layeredPane.setBounds(10, 9, 598, 297);
	       panel_1.add(layeredPane);
	       
	       JButton btnOk = new JButton("OK");
	       btnOk.setBounds(415, 237, 108, 23);
	       layeredPane.add(btnOk);
	       
	       c = new JCalendar ();
	       c.setBounds(365, 31, 200, 200);
	       layeredPane.add(c);
	       
	       JList list = new JList();
	       list.setBounds(10, 51, 323, 155);
	       layeredPane.add(list);
	       
	       JLabel lblNewLabel = new JLabel("Liste des �v�nements de la semaine");
	       lblNewLabel.setBounds(10, 31, 256, 14);
	       layeredPane.add(lblNewLabel);
	       
	       JButton btnSinscrire = new JButton("S'inscrire");
	       btnSinscrire.setBounds(98, 248, 137, 27);
	       layeredPane.add(btnSinscrire);
	       
	       JButton btnDtailDesvnements = new JButton("D\u00E9tail des \u00E9v\u00E9nements");
	       btnDtailDesvnements.setBounds(164, 215, 169, 27);
	       layeredPane.add(btnDtailDesvnements);
	       
	
	       
	       JButton btnNewButton = new JButton("Afficher Participants");
	       btnNewButton.setBounds(10, 215, 153, 27);
	       layeredPane.add(btnNewButton);
	       btnNewButton.addActionListener(new ActionListener() {
	       	public void actionPerformed(ActionEvent e) {
	       	}
	       });
	       c.setVisible(true);
	       
	       JMenuBar menuBar = new JMenuBar();
	       frame.setJMenuBar(menuBar);
	       
	       JMenu mnOptions = new JMenu("Options");
	       menuBar.add(mnOptions);
	       
	       JMenuItem mntmDconnexion = new JMenuItem("D\u00E9connexion");
	       mnOptions.add(mntmDconnexion);
	       
	       JSeparator separator = new JSeparator();
	       mnOptions.add(separator);
	       
	       JMenuItem mntmNewMenuItem = new JMenuItem("Quitter");
	       mnOptions.add(mntmNewMenuItem);
	}
}
