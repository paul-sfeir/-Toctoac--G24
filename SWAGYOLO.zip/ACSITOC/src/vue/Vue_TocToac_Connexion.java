package vue;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.GridLayout;
import javax.swing.BoxLayout;

import Modele.Utilisateur;

import java.awt.FlowLayout;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Vue_TocToac_Connexion {

	private JFrame frame;
	private JPasswordField passwordField;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {	
		/* cr�ation du premier utilisateur
		Utilisateur Admin = new Utilisateur(1, "BigBrother","SWAG", 1);
		try {
		FileOutputStream fichier = new FileOutputStream("personne.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fichier);
		oos.writeObject(Admin);
		oos.flush();
		oos.close();
		}
		catch (java.io.IOException e) {
			e.printStackTrace();
		}
		*/
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vue_TocToac_Connexion window = new Vue_TocToac_Connexion();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Vue_TocToac_Connexion() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 463, 158);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(51, 39, 151, 50);
		frame.getContentPane().add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("Identifiant");
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		panel.add(textField);
		textField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(207, 39, 175, 50);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Mot de passe : ");
		panel_1.add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		panel_1.add(passwordField);
		
		JLabel lblVeuillezEntrerVotre = new JLabel("Veuillez entrer votre identifiant et votre mot de passe :");
		lblVeuillezEntrerVotre.setBounds(63, 14, 325, 14);
		frame.getContentPane().add(lblVeuillezEntrerVotre);
	
		
		
	}
}
