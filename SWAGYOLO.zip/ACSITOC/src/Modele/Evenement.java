package Modele;

import java.util.Date;
import java.util.Vector;

public class Evenement implements java.io.Serializable {

	private int idEvenement;
	private String nomEvenement;
	public int getIdEvenement() {
		return idEvenement;
	}

	public void setIdEvenement(int idEvenement) {
		this.idEvenement = idEvenement;
	}

	public String getNomEvenement() {
		return nomEvenement;
	}

	public void setNomEvenement(String nomEvenement) {
		this.nomEvenement = nomEvenement;
	}

	public String getLieuxEvenement() {
		return lieuxEvenement;
	}

	public void setLieuxEvenement(String lieuxEvenement) {
		this.lieuxEvenement = lieuxEvenement;
	}

	public Date getDateEvenement() {
		return dateEvenement;
	}

	public void setDateEvenement(Date dateEvenement) {
		this.dateEvenement = dateEvenement;
	}

	public int getNbPartEvenement() {
		return nbPartEvenement;
	}

	public void setNbPartEvenement(int nbPartEvenement) {
		this.nbPartEvenement = nbPartEvenement;
	}

	public String getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(String idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}

	public Vector<String> getListeIdActivite() {
		return listeIdActivite;
	}

	public void setListeIdActivite(Vector<String> listeIdActivite) {
		this.listeIdActivite = listeIdActivite;
	}

	private String lieuxEvenement;
	private Date dateEvenement;
	private int nbPartEvenement;
	
	private String idUtilisateur;
	private Vector<String> listeIdActivite;
	
	public Evenement(int _idEvenement, String _nomEvenement, Date _dateEvenement){
		this(_idEvenement, _nomEvenement, _dateEvenement, "");
	}

	public Evenement(int _idEvenement, String _nomEvenement, Date _dateEvenement, String _lieuxEvenement){
		this(_idEvenement, _nomEvenement, _dateEvenement, _lieuxEvenement, new Vector<String>());
	}
	
	public Evenement(int _idEvenement, String _nomEvenement, Date _dateEvenement, String _lieuxEvenement, Vector _listeIdActivite){
		this.idEvenement = _idEvenement;
		this.nomEvenement = _nomEvenement;
		this.dateEvenement = _dateEvenement;
		this.lieuxEvenement = _lieuxEvenement;
		
		listeIdActivite = new Vector<String>(_listeIdActivite.size());
		listeIdActivite.addAll(_listeIdActivite);
	}	
}
